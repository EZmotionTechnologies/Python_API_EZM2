import minimalmodbus
import serial
# import EZMotionMMS2.src.EZMotionMMS2_pk.EZMotionMMS2
# __all__ = ["EZMotionMMS2"]
#
import EZMotionMMS2
from .EZMotionMMS2 import *
